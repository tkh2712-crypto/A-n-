# A Drive – Website thi thử lý thuyết mô tô hạng A

Website chạy trực tiếp trong trình duyệt, xây dựng bằng HTML, CSS và JavaScript thuần. Có thể dùng không cần cài đặt Node.js hay máy chủ, hoặc tải toàn bộ thư mục lên Cloudflare Pages.

## Cách mở

1. Giải nén `GPLX_Hang_A_Website.zip`.
2. Mở tệp `index.html` bằng Chrome hoặc Edge. **Không di chuyển riêng index.html ra khỏi thư mục**, vì phải giữ `app.js`, `data.js`, `styles.css` và thư mục `assets`.
3. Chọn **Bắt đầu thi thử** hoặc **Luyện tập 250 câu**.
4. Muốn xuất bản trực tuyến, upload **toàn bộ nội dung thư mục** lên Cloudflare Pages. Không cần lệnh build; thư mục đầu ra là thư mục chứa `index.html`.

## Nguồn dữ liệu thực tế

Ngân hàng `questions.json` và `data.js` được trích từ tệp PDF người dùng cung cấp:

**Cục Cảnh sát giao thông (Bộ Công an). _250 câu hỏi dùng cho sát hạch lái xe mô tô trong lực lượng Công an nhân dân_. Hà Nội, 2024.**

**Đây là tài liệu chuyên biệt dành cho lực lượng Công an nhân dân, không đồng nhất với bộ câu hỏi mô tô phổ thông công bố cho thí sinh ngoài lực lượng từ năm 2025.** Website luôn hiện cảnh báo về nguồn này. Các câu hỏi và đáp án được trích từ văn bản PDF theo vị trí gạch chân; phần đồ họa biển báo và sa hình được cắt ra trực tiếp từ các trang. Không tạo hoặc suy đoán đáp án giả.

- 250/250 câu hỏi và đáp án được tự động trích xuất, kiểm tra cấu trúc. **Nên đối chiếu lại với bản PDF trước khi sử dụng vào sát hạch thật.**
- 80 hình minh họa từ 50 câu biển báo và 30 câu sa hình; 2 biểu tượng dạng đồ họa vector được trích từ ảnh trang PDF.
- **Câu 70:** PDF gốc trang 18 bị đánh số `1.` hai lần trong các phương án; website sửa nhãn của phương án thứ hai thành `2.` (chỉ sửa nhãn, không sửa nội dung hoặc đáp án), kèm ghi chú rõ ràng.
- **Câu 134 và 189:** định dạng nhiều đáp án trên cùng một dòng trong PDF được tách thành các phương án riêng; nội dung giữ nguyên.
- File PDF không có lời giải thích chi tiết và **không có danh mục xác nhận 20 câu điểm liệt**. Website không tự nghĩ ra 20 câu đó, không gắn nhãn ngẫu nhiên, không tự tạo căn cứ pháp lý.

## Tính năng

- Thi thử 25 câu / 19 phút / mốc 23 câu đúng (2026); câu hỏi không trùng; tự nộp khi hết giờ; dùng đồng hồ tuyệt đối chống việc chuyển tab làm chậm thời gian; lưu bài đang thi khi tải lại.
- Đề mô phỏng gồm 8 câu quy tắc + 1 câu điểm liệt đã được người dùng xác minh + 1 văn hóa + 1 kỹ thuật + 8 biển báo + 6 sa hình. **Trước khi có danh sách điểm liệt, hệ thống chọn 9 câu quy tắc** và hiển thị cảnh báo không kết luận đỗ kỳ thi chính thức.
- Luyện tập theo 6 chương gốc: 90 quy tắc, 50 biển báo, 45 kỹ thuật, 30 sa hình, 30 văn hóa, 5 PCCC và sơ cứu.
- Chức năng điểm liệt chỉ hoạt động sau khi người dùng nhập **chính xác 20 mã câu và thông tin nguồn xác minh** trong Quản lý dữ liệu. Chỉ áp dụng với bộ câu đã đối chiếu.
- Xem lại đáp án, ôn câu sai, câu đã lưu, câu chưa học; lưu tiến độ và thống kê trong `localStorage`.
- Nhập ngân hàng JSON, CSV, XLSX một sheet (đúng cấu trúc tiêu đề); xuất JSON và CSV; khôi phục bản gốc.
- Responsive cho điện thoại; hỗ trợ chế độ sáng và tối; dùng được offline (font chữ mặc định hệ thống khi không có mạng).

## Cấu trúc bản nhập CSV/XLSX

`id,question,option1,option2,option3,option4,answer,category,image`

- `answer`: số thứ tự đáp án đúng 1–4.
- `category`: `rules`, `signs`, `skills`, `situations`, `culture`, hoặc `emergency`.
- `image`: một đường dẫn đến hình có sẵn trên website, HTTP(S) hoặc data:image/... URL.
- Cần ít nhất 25 câu hợp lệ; ứng dụng từ chối tệp trùng mã, thiếu đáp án hoặc sai cấu trúc. CSV UTF-8 có dấu phẩy được đặt trong dấu nháy kép.

## Cấu trúc từ 01/3/2027

Thông tư 108/2026/TT-BCA thay đổi đề hạng A sang **40 câu / 27 phút / ít nhất 36 câu đúng**, bỏ chế độ điểm liệt từ **01/3/2027**. Ngân hàng PDF 2024 **không** phải bộ câu phù hợp để mô phỏng chính thức theo cấu trúc mới.

Ứng dụng không tự chuyển sang chế độ thi 2027 nếu chưa có ngân hàng và bản phân bổ đã xác minh. Để kích hoạt sau khi có dữ liệu thực tế, tệp JSON nhập phải chứa metadata:

```json
{
  "title": "Ngân hàng mới 2027 đã được xác minh",
  "sourceEdition": "2027",
  "edition2027Verified": true,
  "examBlueprint2027": {
    "rules": 10,
    "signs": 10,
    "skills": 5,
    "situations": 8,
    "culture": 5,
    "emergency": 2
  }
}
```

**CẢNH BÁO:** Chỉ là ví dụ minh họa định dạng dữ liệu, các con số phân bổ ở trên **không phải quy định thật**. Phải thay chúng bằng phân bổ chính thức đã được xác minh rồi mới đưa vào dùng.

## Tệp chính

- `index.html`: trang HTML.
- `styles.css`: giao diện.
- `app.js`: các chức năng thi/luyện tập/nhập dữ liệu/chấm điểm.
- `data.js`: ngân hàng 250 câu nhúng để chạy được ngay với `file://`.
- `questions.json`: bản ngân hàng JSON độc lập để nhập/xuất, bảo trì.
- `assets/`: hình minh họa câu hỏi.

> Đây là công cụ ôn tập độc lập, không phải phần mềm sát hạch chính thức. Hãy xác minh phiên bản ngân hàng câu hỏi và quy định áp dụng với đơn vị sát hạch của bạn.
